#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include<bits/stdc++.h>
#define PI acos(-1)
#define fs first
#define sc second
#define pdd pair<double,double>
#define dp pair<pdd,pdd>
using namespace std;

const int INSIDE = 0;
const int LEFT = 1;
const int RIGHT = 2;
const int BOTTOM = 4;
const int TOP = 8;
int x_max,y_max,x_min,y_min;
vector<dp>v;
int n;

int koi(double x, double y)
{
    int ret=INSIDE;
    if(x<x_min) ret|=LEFT;
    else if(x>x_max)ret|=RIGHT;
    if(y<y_min)ret|=BOTTOM;
    else if(y>y_max)ret |= TOP;
    return ret;
}
dp sutherland(int i)
{
    double x1=v[i].fs.fs;
    double y1=v[i].fs.sc;
    double x2=v[i].sc.fs;
    double y2=v[i].sc.sc;
    int code1 = koi(x1, y1);
    int code2 = koi(x2, y2);
    bool accept = false;
    while (true)
    {
        if ((code1==0) && (code2==0))
        {
            accept = true;
            break;
        }
        else if (code1&code2) break;
        else
        {
            int code_out;
            double x, y;
            if (code1 != 0) code_out = code1;
            else code_out = code2;
            if (code_out & TOP) x = x1 + (x2 - x1) * (y_max - y1) / (y2 - y1),y = y_max;
            else if (code_out & BOTTOM) x = x1 + (x2 - x1) * (y_min - y1) / (y2 - y1),y = y_min;
            else if (code_out & RIGHT) y = y1 + (y2 - y1) * (x_max - x1) / (x2 - x1),x = x_max;
            else if (code_out & LEFT) y = y1 + (y2 - y1) * (x_min - x1) / (x2 - x1),x = x_min;
            if (code_out == code1) x1 = x,y1 = y,code1 = koi(x1, y1);
            else x2 = x,y2 = y,code2 = koi(x2, y2);
        }
    }
    if (accept) return dp({{x1,y1},{x2,y2}});
    else return dp({{1<<30,0},{0,0}});
}
static void algo(void){
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_LINE_LOOP);
        glVertex2d(x_min,y_min);
        glVertex2d(x_min,y_max);
        glVertex2d(x_max,y_max);
        glVertex2d(x_max,y_min);
    glEnd();
    glClearColor(0.0,0.0,0.0,0);
    glColor3f(1.0,0.0,0.0);
    for(int i=0;i<n;i++)
    {
        dp r=sutherland(i);
        if(r.fs.fs==1<<30) continue;
        glBegin(GL_LINE_LOOP);
            glVertex2d(r.fs.fs,r.fs.sc);
            glVertex2d(r.sc.fs,r.sc.sc);
        glEnd();
    }
    glutSwapBuffers();
}
int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
    glutInitWindowSize(640,640);
    glutInitWindowPosition(20,20);

    cin>>x_min>>y_min>>x_max>>y_max;
    cin>>n;
    dp in;
    for(int i=0;i<n;i++) cin>>in.fs.fs>>in.fs.sc>>in.sc.fs>>in.sc.sc,v.push_back(in);
    glutCreateWindow("Line Clipping");
    glClearColor(0.0,0.0,0.0,0);
    glColor3f(0.0,1.0,0.0);
    gluOrtho2D(-100.0,100.0,-100.0,100.0);
    glutDisplayFunc(algo);
    glutMainLoop();
    return EXIT_SUCCESS;
}
/*
4 4 10 8
3
5 5 7 7
7 9 11 4
1 5 4 1
*/
